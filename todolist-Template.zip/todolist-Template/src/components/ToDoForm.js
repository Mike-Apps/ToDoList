import React, { useState, useEffect, useRef } from 'react'

function ToDoForm(props) {
    //useState( props.edit ? props.edit.value : '' ); is a way of not clearing out the item you are trying to edit
    //instead, it allows you to edit the text.  
    const [input, setInput] = useState(props.edit ? props.edit.value : '');

    const inputRef = useRef(null);

    useEffect(() => {
        inputRef.current.focus();
    });

    const handleChange = e => {
        setInput(e.target.value);
    }

    const handeSubmit = e => {
        e.preventDefault();
        props.onSubmit({
            id: Math.floor(Math.random() * 100000),
            text: input,
        });

        setInput('');
    }



    return (
        <form className='todo-form' onSubmit={handeSubmit}>
            {props.edit ? (
                <>
                    <input
                        placeholder='Update Item'
                        className='todo-input edit'
                        value={input}
                        name='text'
                        type='text'
                        onChange={handleChange} ref={inputRef}
                    />

                    <button className='todo-button edit'>Update</button>
                </>
                //ternary
            ) :

                (
                    <>
                        <input
                            placeholder='todo here'
                            className='todo-input'
                            value={input}
                            name='text'
                            type='text'
                            onChange={handleChange} ref={inputRef}
                        />

                        <button className='todo-button'>add todo</button>


                    </>
                )
            }

        </form>
    )
}

export default ToDoForm
